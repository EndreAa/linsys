% FOR HELICOPTER NR 3-10
% This file contains the initialization for the helicopter assignment in
% the course TTK4115. Run this file before you execute QuaRC_ -> Build 
% to build the file heli_q8.mdl.

% Oppdatert h�sten 2006 av Jostein Bakkeheim
% Oppdatert h�sten 2008 av Arnfinn Aas Eielsen
% Oppdatert h�sten 2009 av Jonathan Ronen
% Updated fall 2010, Dominik Breu
% Updated fall 2013, Mark Haring
% Updated spring 2015, Mark Haring


%%%%%%%%%%% Calibration of the encoder and the hardware for the specific
%%%%%%%%%%% helicopter
Joystick_gain_x = 1;
Joystick_gain_y = -1;


%%%%%%%%%%% Physical constants
g = 9.81; % gravitational constant [m/s^2]
l_c = 0.46; % distance elevation axis to counterweight [m]
l_h = 0.66; % distance elevation axis to helicopter head [m]
l_p = 0.175; % distance pitch axis to motor [m]
m_c = 1.92; % Counterweight mass [kg]
m_p = 0.72; % Motor mass [kg]



%%%%%%%%%% Matrices
J_p = 2*m_p*l_p^2;
J_e = m_c*l_c^2+2*m_p*l_h^2;
K_f = 8;
K1 = l_p*K_f/(J_p);
K2 = K_f*l_h/J_e;
A = [0 1 0; 0 0 0; 0 0 0];
B = [0 0; 0 K1; K2 0];
C = [1 0 0; 0 0 1];
Q = diag([10 1 2]);
R = diag([0.5 2]);
K = lqr(A,B,Q,R);

F = inv(C*inv(B*K-A)*B);

A2 = [A zeros(3,2); -C zeros(2)]
B2 = [B;zeros(2)]
G = [zeros(3,2); eye(2)];
C2 = [C zeros(2)]

Q2 = diag([10 1 1 1 1]);
R2 = diag([1 1]);

ctrb(A2, B2)
rank(ctrb(A2, B2)) == size(A2,1)

K2 = lqr(A2, B2, Q2, R2);

F2 = inv(B2)*((B2*K2-A2)*inv(C2)-G)



